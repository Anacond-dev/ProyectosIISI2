"use strict";

import { parseHTML } from "../utils/parseHTML.js";

const artistRenderer = {
    asCard: function(artist){
        let html = `
    <div class="card mb-3 p-3">
                <div class="row g-3">
                    <div class="col-md-2 d-flex align-items-center">
                        <div class="image-box">
                            <img src="${artist.imageUrl}" class="img-fluid">
                        </div>
                    </div>

                    <div class="col-md-10">
                        <h3 class="card-title">${artist.name}</h3>
                        <p class="card-text"> ${artist.bio}</p>
                        <div class="d-flex align-items-center user-info mt-3">
                        <div class="user-icon">
                            <img src="${artist.avatarUrl}" class="rounded-circle me-2 w-50">
                        </div>
                        <span><strong>carevalo</strong> -Edad: ${artist.age}</span>

                    </div>
                </div>
        </div>`
    let card = parseHTML(html);
    return card;

    }
};

export { artistRenderer };