
import { artistRenderer } from "./renderers/artists.js";
import { messageRenderer } from "./renderers/messages.js";
import { artistswithusersAPI_auto } from "./api/_artistswithusers.js";



async function handleFormSubmit(e) {
    e.preventDefault();

    document.getElementById("errors").innerHTML = "";

    let form = document.getElementById("formid");
    let formData = new FormData(form);

    
    const userId = sessionManager.getLoggedId();
    if (!userId) {
        messageRenderer.showErrorMessage("Debes iniciar sesión para crear un proyecto");
        return;
    }

    
    formData.set("userId", String(userId));

    const errors = artistValidator.validatenewartist(formData);

    if (errors.length > 0) {
        for (let error of errors) {
            messageRenderer.showErrorMessage(error);
        }
        return;
    }

    try {
        const response = await artistsAPI_auto.create(formData);
        messageRenderer.showSuccessMessage("Proyecto registrado con éxito");
        form.reset();

        setTimeout(() => {
            window.location.href = "projects.html";
        }, 2000);

    } catch (error) {
        console.error("Error al crear el proyecto:", error);
        let errorMessage = "El formulario no ha sido enviado correctamente";
        if (error.response && error.response.data && error.response.data.message) {
            errorMessage = error.response.data.message;
        }
        messageRenderer.showErrorMessage(errorMessage);
    }
}