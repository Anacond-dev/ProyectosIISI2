"use strict";

import { artistRenderer } from "./renderers/artists.js";
import { messageRenderer } from "./renderers/messages.js";
import { artistswithusersAPI_auto } from "./api/_artistswithusers.js";

async function main() {
    // Main function that will run when the page is ready
    loadartists();
}

async function loadartists() {
    
    try{
        
        let artists = await artistswithusersAPI_auto.getAll();
        let divGallery = document.getElementById("divGallery");

        for(let artist of artists){
            let card = artistRenderer.asCard(artist);
            divGallery.appendChild(card);
        }
    }catch(err){
        messageRenderer.showErrorMessage("Error", err);
    }
}

document.addEventListener("DOMContentLoaded", main);