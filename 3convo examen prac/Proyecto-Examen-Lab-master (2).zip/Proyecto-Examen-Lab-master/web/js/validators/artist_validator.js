"use strict";

import { sessionManager } from "../utils/session.js";

const artistValidator = {
    validatenewartist: function(formData){
        let errors = [];

        let artistname = formData.get("name");
        let numalbum = formData.get("numAlbums");

        if(artistName <= 0 && artistName.lenght % 5 !== 0){
            error.push("El nombre debe de tener una longitud mayor a 0 y el numero de letras de su nombre multiplo de 5");
        }
        if(numalbum <= 0 && numalbum >= 20){
            error.push("El numero de albums debe de ser mayor que 0 y menor que 20");
        }

        return errors;
    }
}

export { artistValidator };